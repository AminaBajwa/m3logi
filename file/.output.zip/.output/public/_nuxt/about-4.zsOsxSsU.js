import"./entry.D5UbSBlD.js";const o=""+globalThis.__publicAssetsURL("images/resource/about-3.jpg"),t=""+globalThis.__publicAssetsURL("images/resource/about-4.jpg");export{o as _,t as a};
