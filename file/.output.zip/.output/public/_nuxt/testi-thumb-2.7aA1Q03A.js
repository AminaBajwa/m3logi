import"./entry.D5UbSBlD.js";const t=""+globalThis.__publicAssetsURL("images/resource/testi-thumb-2.jpg");export{t as _};
