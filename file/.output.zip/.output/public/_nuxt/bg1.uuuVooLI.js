import"./entry.D5UbSBlD.js";const o=""+globalThis.__publicAssetsURL("images/resource/bg1.jpg");export{o as _};
