import { p as publicAssetsURL } from '../../handlers/renderer.mjs';

const _imports_3 = "" + publicAssetsURL("images/resource/service-1.jpg");
const _imports_1 = "" + publicAssetsURL("images/resource/service-2.jpg");
const _imports_0 = "" + publicAssetsURL("images/resource/service-3.jpg");
const _imports_2 = "" + publicAssetsURL("images/resource/service-4.jpg");

export { _imports_3 as _, _imports_1 as a, _imports_0 as b, _imports_2 as c };
//# sourceMappingURL=service-4-4xo4pTju.mjs.map
