import { p as publicAssetsURL } from '../../handlers/renderer.mjs';

const _imports_0 = "" + publicAssetsURL("images/resource/bg1.jpg");

export { _imports_0 as _ };
//# sourceMappingURL=bg1-9FCO0GRH.mjs.map
