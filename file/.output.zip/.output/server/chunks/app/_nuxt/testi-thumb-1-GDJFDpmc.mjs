import { p as publicAssetsURL } from '../../handlers/renderer.mjs';

const _imports_0 = "" + publicAssetsURL("images/resource/testi-thumb-1.jpg");

export { _imports_0 as _ };
//# sourceMappingURL=testi-thumb-1-GDJFDpmc.mjs.map
