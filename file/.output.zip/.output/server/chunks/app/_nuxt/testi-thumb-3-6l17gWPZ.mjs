import { p as publicAssetsURL } from '../../handlers/renderer.mjs';

const _imports_2 = "" + publicAssetsURL("images/resource/testi-thumb-3.jpg");

export { _imports_2 as _ };
//# sourceMappingURL=testi-thumb-3-6l17gWPZ.mjs.map
