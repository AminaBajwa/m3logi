import { p as publicAssetsURL } from '../../handlers/renderer.mjs';

const _imports_0 = "" + publicAssetsURL("images/resource/project-1.jpg");
const _imports_1 = "" + publicAssetsURL("images/resource/project-2.jpg");
const _imports_2 = "" + publicAssetsURL("images/resource/project-3.jpg");
const _imports_3 = "" + publicAssetsURL("images/resource/project-4.jpg");

export { _imports_0 as _, _imports_1 as a, _imports_2 as b, _imports_3 as c };
//# sourceMappingURL=project-4-9sH5mCY_.mjs.map
