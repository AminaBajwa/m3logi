import { p as publicAssetsURL } from '../../handlers/renderer.mjs';

const _imports_0 = "" + publicAssetsURL("images/resource/about-3.jpg");
const _imports_1 = "" + publicAssetsURL("images/resource/about-4.jpg");

export { _imports_0 as _, _imports_1 as a };
//# sourceMappingURL=about-4-7KiI2d46.mjs.map
