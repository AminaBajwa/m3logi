import { p as publicAssetsURL } from '../../handlers/renderer.mjs';

const _imports_0 = "" + publicAssetsURL("images/resource/team-1.jpg");
const _imports_1 = "" + publicAssetsURL("images/resource/team-2.jpg");
const _imports_2 = "" + publicAssetsURL("images/resource/team-3.jpg");

export { _imports_0 as _, _imports_1 as a, _imports_2 as b };
//# sourceMappingURL=team-3-iV7YWsR1.mjs.map
