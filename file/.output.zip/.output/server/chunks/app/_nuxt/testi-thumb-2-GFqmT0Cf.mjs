import { p as publicAssetsURL } from '../../handlers/renderer.mjs';

const _imports_1 = "" + publicAssetsURL("images/resource/testi-thumb-2.jpg");

export { _imports_1 as _ };
//# sourceMappingURL=testi-thumb-2-GFqmT0Cf.mjs.map
